package com.example.servicenote

import android.app.Activity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.servicenote.data.ServiceItem
import com.example.servicenote.data.ServiceNote
import com.example.servicenote.databinding.ActivityCreateNoteBinding
import java.util.*

class CreateNoteActivity : AppCompatActivity() {
    private lateinit var b: ActivityCreateNoteBinding
    private val vm: com.example.servicenote.ui.MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityCreateNoteBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnSave.setOnClickListener {
            val customer = b.etCustomer.text.toString().ifBlank { "Unknown" }
            val phone = b.etPhone.text.toString().ifBlank { null }
            val device = b.etDevice.text.toString().ifBlank { null }
            val desc = b.etItemDesc.text.toString().ifBlank { "Service" }
            val qty = b.etQty.text.toString().toIntOrNull() ?: 1
            val rate = b.etRate.text.toString().toDoubleOrNull() ?: 0.0
            val item = ServiceItem(description = desc, qty = qty, rate = rate)
            val subtotal = item.amount
            val taxPercent = b.etTax.text.toString().toDoubleOrNull() ?: 0.0
            val tax = subtotal * taxPercent / 100.0
            val total = subtotal + tax
            val note = ServiceNote(customerName = customer, customerPhone = phone, deviceModel = device, dateEpoch = Date().time, subtotal = subtotal, tax = tax, total = total, noteText = b.etNote.text.toString())

            vm.saveNote(note, listOf(item)) { id ->
                val file = PdfUtil.createPdf(this, note.copy(id = id), listOf(item))
                PdfUtil.sharePdf(this, file)
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
    }
}
