package com.example.servicenote

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.servicenote.data.ServiceNote
import com.example.servicenote.databinding.RowNoteBinding

class NotesAdapter : ListAdapter<ServiceNote, NotesAdapter.VH>(DIFF) {
    companion object { private val DIFF = object : DiffUtil.ItemCallback<ServiceNote>() {
        override fun areItemsTheSame(old: ServiceNote, new: ServiceNote) = old.id == new.id
        override fun areContentsTheSame(old: ServiceNote, new: ServiceNote) = old == new
    } }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(RowNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(private val b: RowNoteBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(note: ServiceNote) {
            b.tvCustomer.text = note.customerName
            b.tvDate.text = java.text.SimpleDateFormat("dd/MM/yyyy").format(java.util.Date(note.dateEpoch))
            b.tvTotal.text = String.format("₹%.2f", note.total)
        }
    }
}
