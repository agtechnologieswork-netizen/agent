package com.example.servicenote

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.servicenote.data.ServiceItem
import com.example.servicenote.data.ServiceNote
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfUtil {
    fun createPdf(context: Context, note: ServiceNote, items: List<ServiceItem>): File {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdf.startPage(pageInfo)
        val c = page.canvas
        val paint = Paint()
        paint.textSize = 14f
        var y = 40
        c.drawText("Service Note", 20f, y.toFloat(), paint); y += 24
        paint.textSize = 12f
        c.drawText("Note #: ${note.id}", 20f, y.toFloat(), paint); y += 18
        c.drawText("Date: ${SimpleDateFormat("dd/MM/yyyy").format(Date(note.dateEpoch))}", 20f, y.toFloat(), paint); y += 18
        c.drawText("Customer: ${note.customerName}", 20f, y.toFloat(), paint); y += 18
        c.drawText("Device: ${note.deviceModel ?: "-"}", 20f, y.toFloat(), paint); y += 20
        c.drawText("Description", 20f, y.toFloat(), paint)
        c.drawText("Qty", 360f, y.toFloat(), paint)
        c.drawText("Rate", 420f, y.toFloat(), paint)
        c.drawText("Amount", 500f, y.toFloat(), paint)
        y += 18
        for (it in items) {
            c.drawText(it.description, 20f, y.toFloat(), paint)
            c.drawText(it.qty.toString(), 360f, y.toFloat(), paint)
            c.drawText(String.format("%.2f", it.rate), 420f, y.toFloat(), paint)
            c.drawText(String.format("%.2f", it.amount), 500f, y.toFloat(), paint)
            y += 16
        }
        y += 20
        c.drawText("Subtotal: ₹${String.format("%.2f", note.subtotal)}", 380f, y.toFloat(), paint); y += 18
        c.drawText("Tax: ₹${String.format("%.2f", note.tax)}", 380f, y.toFloat(), paint); y += 18
        c.drawText("Total: ₹${String.format("%.2f", note.total)}", 380f, y.toFloat(), paint)
        pdf.finishPage(page)
        val file = File(context.getExternalFilesDir(null), "service_note_${note.id}.pdf")
        pdf.writeTo(FileOutputStream(file))
        pdf.close()
        return file
    }

    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share PDF"))
    }
}
