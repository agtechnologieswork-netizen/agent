package com.example.servicenote.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_notes")
data class ServiceNote(
    @PrimaryKey(autoGenerate = true) var id: Long = 0,
    val customerName: String,
    val customerPhone: String?,
    val deviceModel: String?,
    val dateEpoch: Long,
    val subtotal: Double,
    val tax: Double,
    val total: Double,
    val noteText: String?
)
