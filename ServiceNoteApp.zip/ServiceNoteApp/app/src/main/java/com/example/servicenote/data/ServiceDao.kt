package com.example.servicenote.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceDao {
    @Insert suspend fun insertNote(note: ServiceNote): Long
    @Insert suspend fun insertItems(items: List<ServiceItem>)
    @Query("SELECT * FROM service_notes ORDER BY dateEpoch DESC")
    fun getAllNotes(): Flow<List<ServiceNote>>
    @Query("SELECT * FROM service_items WHERE noteId = :noteId")
    suspend fun getItemsForNote(noteId: Long): List<ServiceItem>
}
