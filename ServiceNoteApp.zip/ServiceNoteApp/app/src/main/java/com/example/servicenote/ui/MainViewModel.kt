package com.example.servicenote.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.servicenote.data.AppDatabase
import com.example.servicenote.data.ServiceRepository
import com.example.servicenote.data.ServiceNote
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = ServiceRepository(AppDatabase.get(application).serviceDao())
    val notes = repo.allNotes().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun saveNote(note: ServiceNote, items: List<com.example.servicenote.data.ServiceItem>, onSaved: (Long)->Unit) {
        viewModelScope.launch {
            val id = repo.saveNoteWithItems(note, items)
            onSaved(id)
        }
    }
}
