package com.example.servicenote.data

class ServiceRepository(private val dao: ServiceDao) {
    fun allNotes() = dao.getAllNotes()
    suspend fun saveNoteWithItems(note: ServiceNote, items: List<ServiceItem>) : Long {
        val id = dao.insertNote(note)
        items.forEach { it.noteId = id }
        dao.insertItems(items)
        return id
    }
    suspend fun getItems(noteId: Long) = dao.getItemsForNote(noteId)
}
