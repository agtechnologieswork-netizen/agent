package com.example.servicenote

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

fun <T> Flow<T>.collectWhenStarted(activity: AppCompatActivity, collector: (T)->Unit) {
    activity.lifecycleScope.launch { collect { collector(it) } }
}
