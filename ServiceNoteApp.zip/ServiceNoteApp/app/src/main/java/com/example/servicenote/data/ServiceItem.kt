package com.example.servicenote.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_items")
data class ServiceItem(
    @PrimaryKey(autoGenerate = true) var id: Long = 0,
    var noteId: Long = 0,
    val description: String,
    val qty: Int,
    val rate: Double
) {
    val amount get() = qty * rate
}
